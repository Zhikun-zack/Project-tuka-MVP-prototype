import React from 'react';
import Recaptcha from 'react-recaptcha';
import {Form, FormGroup, Input, Label, Button} from 'reactstrap';
import axios from 'axios';

const backdropStyle = {
    position:'fixed',
    zIndex:90,
    top:0,
    bottom:0,
    left:0,
    right:0,
    backgroundColor:'rgba(0,0,0,0.3)',
    padding:50,
};

const modalStyle = {
    backgroundColor: '#fff',
    borderRadius:5,
    maxWidth:500,
    minHeight:600,
    margin:'0 auto',
    padding: 30,
    position: 'relative'
};

const headerStyle = {
    position:'absolute',
    top: 20
};

const contentStyle = {
    position:'absolute',
    margin:'5% 5%'
}

export default  class Modal extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            isVerified:false,
            Email:'',
            ConfirmEmail:'',
            Password:'',
            ConfirmPassword:''
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.recaptchaLoaded = this.recaptchaLoaded.bind(this);
        this.verifyCallback = this.verifyCallback.bind(this);
    }

    handleChange = e => {
        this.setState({[e.target.name]: e.target.value})
    };

    async handleSubmit(e){
        e.preventDefault()

        const { Email,ConfirmEmail,Password,ConfirmPassword} = this.state;

        const form = await axios.post('/api/form',{
            Email,
            ConfirmEmail,
            Password,
            ConfirmPassword
        })
    }

    recaptchaLoaded(){
        console.log("capcha loaded");
    }

    verifyCallback(response){
        if(response){
            this.setState({
                isVerified:true
            })
        }
    }
    // onClose = (e) =>{
    //     this.props.onClose && this.props.onClose(e);
    // }
    render() {
        if(this.props.show){
            return null;
        }
        return (
            <div style={backdropStyle}>
                <div style={modalStyle}>
                    <div style={headerStyle}>
                        <button onClick={this.onClose}>
                            Close
                        </button>
                    </div>
                    <div style={contentStyle}>
                        <div>
                            <b>Sign Up</b>
                        </div>
                        <Form onSubmit={this.handleSubmit}>
                            <FormGroup>
                                <Label for="Email" />
                                <Input
                                    type="email"
                                    name="Email"
                                    onChange={this.handleChange}
                                    placeholder="Email"/></FormGroup>
                            <FormGroup>
                                <Label for="ConfirmEmail" />
                                <Input
                                    type="email"
                                    name="ConfirmEmail"
                                    onChange={this.handleChange}
                                    placeholder="Confirm Email"/></FormGroup>
                            <FormGroup>
                                <Label for="Password" />
                                <Input
                                    type="password"
                                    name="Password"
                                    onChange={this.handleChange}
                                    placeholder="Password(8 characters minimum)"/></FormGroup>
                            <FormGroup>
                                <Label for="ConfirmPassword" />
                                <Input
                                    type="password"
                                    name="ConfirmPassword"
                                    onChange={this.handleChange}
                                    placeholder="Confirm Password"/></FormGroup>
                            <Recaptcha
                                sitekey="6Lco76sUAAAAACdWahIKj_ECwE81xKF-96onh8h2"
                                render="explicit"
                                verifyCallback={this.verifyCallback}
                                onloadCallback={this.recaptchaLoaded}
                            />
                            <div><Button>Sign Up</Button></div>
                            <div>By Signing up, you agree to our <span style={{color:'red'}}>Term of Use</span> and
                                <span style={{color:'red'}}> Privacy Policy</span></div>
                            <div>Already have an account? Log In</div>
                        </Form>
                    </div>
                </div>
            </div>
        )
    }
}
